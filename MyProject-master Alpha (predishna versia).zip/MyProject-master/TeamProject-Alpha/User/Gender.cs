﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Users
{
    public enum Gender
    {
        Male,
        Female,
        Other

    }
}
